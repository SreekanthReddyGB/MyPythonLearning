# File Handler...

"""
# READ...
fh=open('FileHandlingDemo.txt', 'r')
# Read First Line..
print(fh.readline())
# Read entire file Line..
print(fh.readlines())
fh.close()
"""

"""
# WRITING...
fh=open('FileHandlingDemo2.txt', 'w')
# Read First Line..
fh.writelines("This is line no.1")
fh.writelines("This is line no.2")
fh.close()
"""
